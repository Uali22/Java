import java.util.ArrayList;

/**
 * A Java tool to draw brick walls
 * 
 * @author (Usman Ali) 
 * @version (a version number or a date)
 */
public class BrickWall
{
    private int wallHeight;
    private int wallWidth;
    private int wallLength;
    private int startX;
    private int startY;
    private int brickWidth;
    private int brickHeight;
    private int currentColor;
    private Rectangle drawBrick;
    private ArrayList <Rectangle> bricks;
    private String[] colors;
    private int FindBrickByColor;
    private int FindBricksByColor;
    private int FindFirstBrickByColour;
    private int findBrickAt;
    private boolean isMultiColored;
    private boolean isDefaultColor;
    private boolean isWallSymmetrical;
    private boolean isDecreasing;
    /**
     * Constructor for objects of class BrickWall.
     * @param rows The number of rows in the wall
     * @param rowlen The maximum number of bricks in a row
     */
    public BrickWall(int wallHeight, int wallWidth)
    {
        setUpColors();
        currentColor = 0;
        this.wallLength = wallWidth;
        this.wallHeight = wallHeight;
        brickWidth = 52;
        brickHeight = 15;
        startX = 20;
        startY = 500;
        bricks = new ArrayList <Rectangle>();
        isMultiColored = true;
        isDefaultColor = true;
        isWallSymmetrical = true;
        isDecreasing = true;   
    }

    private void setUpColors() {
        colors = new String[6];
        colors[0] = "red";
        colors[1] = "yellow";
        colors[2] = "blue";
        colors[3] = "green";
        colors[4] = "magenta";
        colors[5] = "black";    
    }

    /**
     * Draw the wall.  The first brick will be positioned at the coordinates (10, 550).  
     * The number of bricks in a row is specified by setRowLength().  The maximum number of rows
     * is specified by setNumRows().  If decrease is true, each subsequent row of bricks 
     * contains one brick less than the previous row.  If symmetric is true AND decrease is true then
     * the wall is pyramid shaped.  If symmetric is false AND decrease is true then the wall is shaped
     * like a right angle triangle.
     */
    public void draw(int startX, int startY)
    {
        //eraseWall();
    }

    public Rectangle getBrick(int i) {
        return bricks.get(i);
    }

    public void changeColor() {
        currentColor++; 
        for (int i = 0; i >= colors.length; i++) {
            if (currentColor == colors.length) {
                currentColor = 0;
            }
        }
    }

    public void drawRow(int startX,int startY, int wallLength) {
        for (int i = 0; i < wallLength; i++) {
            int xPos = startX + (i*brickWidth);
            drawBrick (xPos, startY);
            if (isMultiColored) {
                nextColor();
            } else { 
                currentColor = 0;
            }
        }
    }
    
    public void toggleMultiColor() {
        isMultiColored = !isMultiColored;
    }
    
    public void toggleSymmetry() {
        isWallSymmetrical = !isWallSymmetrical;
    }
    
    public void toggleDecreasing() {
        isDecreasing = !isDecreasing;
    }

    public void drawBrick(int x, int y) {
        Rectangle brick = new Rectangle(brickWidth, brickHeight);
        brick.setPosition(x, y);
        brick.changeColor(colors[currentColor]);
        bricks.add(brick);
        brick.makeVisible();
    }

    public void draw() {
        eraseWall();
        //drawBrick(startX, startY);
        //drawRow(startX, startY, wallWidth); // 5 bricks long
        //drawWall(this.wallHeight);
        currentColor = 0;
        drawWall(startX, startY, this.wallLength, this.wallHeight);
        //repeat step to view draw wall
    }

    public void drawWall(int StartX, int startY, int wallLength, int numRows) {
        int rowLength = wallLength;
        int xPosition = startX;
        int yPosition = startY;
        for (int i = 0; i < wallHeight; i++) {
            int y = startY - (i * brickHeight);
            drawRow (xPosition, y, rowLength);
            if (isDecreasing) {
                rowLength --;
             if (isWallSymmetrical) {
                 xPosition += (brickWidth/2);
             }
            }
        }
    }

    public void nextColor() {
        currentColor++;
        if (currentColor == 6) {
            currentColor = 0;
        }
    }

    public void eraseWall() {
        Canvas canvas = Canvas.getCanvas();
        for (int i=0; !bricks.isEmpty(); i++) {
            canvas.erase(bricks.remove(0));
        }
    }

    public int getFindBrickByColor(String color) {
        ArrayList <Rectangle> brickColor = new ArrayList<Rectangle>();
        for (Rectangle brick: bricks){
            if (brick.getColor() == color) {
                brickColor.add(brick);
            }
        }
        return brickColor.size();
    }

    public Rectangle getFindFirstBrickByColour(String color) {
        for (Rectangle brick: bricks) {
            if (brick.getColor() == color) {
                return brick;
            }
        }
        return null;
    }

    public ArrayList <Rectangle> getFindBricksByColour(String color) {
        ArrayList <Rectangle> brickColor = new ArrayList<Rectangle>();
        for (Rectangle brick: bricks) {
            if (brick.getColor() == color) {
                brickColor.add(brick);
            }
        }
        return brickColor;
    }

    public Rectangle findBrickAt(int x, int y) {
        ArrayList <Rectangle> brickColor = new ArrayList<Rectangle>();
        for (Rectangle brick: bricks) {
            int xStart = brick.getXPosition();
            int yStart = brick.getYPosition();
            int xEnd = brick.getXPosition() + brickWidth;
            int yEnd = brick.getYPosition() + brickHeight;
            if (x >= xStart && x <= xEnd && y >= yStart && y <= yEnd) {
                return brick;
            }
        }
        return null;
    }

    public Rectangle getBrickByPosition(int x, int y) {
        for (Rectangle brick: bricks) {
            int xStart = brick.getXPosition();
            int yStart = brick.getYPosition();
            int xEnd = xStart + brickWidth;
            int yEnd = yStart + brickHeight;
            if (x >= xStart && x <= xEnd && y >= yStart && y <= yEnd) {
                return brick;
            }
        } return null;
    }

    public void rectangle () {
        drawBrick = new Rectangle();
        drawBrick.changeColor("red");
        // createBrick.changeSize(215,50);
        drawBrick.makeVisible();
    }

    /**
     * Accessor for the colors array
     */
    public String[] getColors(){
        return colors;
    }
}
