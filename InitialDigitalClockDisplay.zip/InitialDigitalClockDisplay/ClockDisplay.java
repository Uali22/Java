
/**
 * Write a description of class ClockDisplay here.
 * 
 * @author (Usman Ali) 
 * @version (a version number or a date)
 */
public class ClockDisplay
{
    private NumberDisplay secondsDisplay;
    private NumberDisplay hoursDisplay;
    private NumberDisplay minutesDisplay;
    private boolean is12Hours;
    /**
     * Constructor for objects of class ClockDisplay
     */
    public ClockDisplay()
    {
        hoursDisplay = new NumberDisplay(24);
        minutesDisplay = new NumberDisplay(60);
        secondsDisplay = new NumberDisplay(60);
        is12Hours = true;
        updateDisplay();
    }

    public void timeTick() {
        secondsDisplay.increment();
        if (secondsDisplay.getValue() == 0) {
            minutesDisplay.increment();
            int minVal = minutesDisplay.getValue();
            if(minVal == 0) {
                hoursDisplay.increment();
            }
        }
        updateDisplay();
    }

    public void setTime(int hours, int minutes) {
        if((hours < 24 || hours >= 0) && (minutes <= 59 || minutes >= 0)) {
            minutesDisplay.setValue(minutes);
            hoursDisplay.setValue(hours);
            updateDisplay();
        } else {
            System.out.println("Enter the corrrect value: hours < 24 && hours > 0, minutes <= 59 && minutes >= 0");
        }
    }

    public NumberDisplay getSeconds() {
        return secondsDisplay;
    }

    public NumberDisplay getHours() {
        return hoursDisplay;
    }

    public NumberDisplay getMinutes() {
        return minutesDisplay;
    }

    public void updateDisplay() {
        String suffix = "";
        int hours = hoursDisplay.getValue();
        if (is12Hours) {
            if (hours >= 12) {
                suffix = "pm";
            } else suffix = "am";
            if (hours > 12) {
                hours = hours - 12;
            } 
            System.out.println(hours + " : " + minutesDisplay.getFormattedValue() + " : "+ secondsDisplay.getFormattedValue() + suffix);
        } else { 
            System.out.println(hoursDisplay.getFormattedValue() + " : " + minutesDisplay.getFormattedValue() + " : "+ secondsDisplay.getFormattedValue());

        }
        //System.out.println(hours.getValue() + "  :  " + minutes.getValue() + "  :  " + seconds.getValue());
    }

    public void switchFormat() {
        is12Hours = !is12Hours;
        updateDisplay();
    }

    public String displayTime() {
        return hoursDisplay.getDisplayValue() + " : " + minutesDisplay.getDisplayValue();
    }

    /*public void printTerminal() {
    System.out.printin(hours.getDisplayValue() + " : " + minutes.getDisplayValue());
    }*/

    /*public String updateDisplay12Hour() {
    if (gethoursDisplay.getValue() >= 12) {
    suffix = "pm";
    } else {
    return suffix = "am";
    }
    }*/

    public void showTheClockRunning(){
        ClockDisplay clock = new ClockDisplay();
        int tickThisManyTimes = 999999;
        int waitThisLongBetweenTicks = 1000;
        while(0 < tickThisManyTimes--){
            clock.timeTick();
            try{
                Thread.sleep(waitThisLongBetweenTicks);
            }catch(InterruptedException ie){}
        }
    }
}