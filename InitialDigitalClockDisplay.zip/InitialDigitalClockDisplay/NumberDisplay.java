
/**
 * Write a description of class NumberDisplay here.
 * 
 * @author (Usman Ali) 
 * @version (a version number or a date)
 */
public class NumberDisplay
{
    private int value;
    private int limit;
    /**
     * Constructor for objects of class NumberDisplay
     */
    public NumberDisplay(int limit)
    {
        this.limit = limit;
        value = 0;      
    }

    public int getValue() {
        return value;
    }
    
    public void setValue(int newValue) {
        value = newValue;
    }

    public int getLimit() {
        return limit;
    }

    public void increment() {
        value = value + 1;
        if(value == limit) {
            value = 0;
        }
    }

    public String getDisplayValue() {
        if (value < 10) {
            return "0" + value;
        } else {
            return "" + value;
        }
    }

    public String getFormattedValue() {
        if (value < 10) {
            return "0" + value;
        } else {
            return "" + value;
        }
    }
}