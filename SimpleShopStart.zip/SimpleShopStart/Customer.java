
/**
 * Write a description of class Customer here.
 *
 * @author (Usman Ali)
 * @version (a version number or a date)
 */
public class Customer
{
    // instance variables - replace the example below with your own
    private int amountSpent;
    private int budget;
    private Shop currentShop;
    private boolean isUnlimitedBudget;
    private Shop shop1 = new Shop(150);
    private Shop shop2 = new Shop(200);
    private int buy;
    private int price;
    private int sold;
    private int numberOfItemsPurchased;
    /**
     * Constructor for objects of class Customer
     */
    public Customer()
    {
        // initialise instance variables
        this.isUnlimitedBudget = true;
        amountSpent = 0;
        currentShop = null;
        totalBudget();
    }

    public int getAmountSpent() {
        return amountSpent;
    }

    public void enter(Shop shop) {
        if (currentShop == null) {
            currentShop = shop;
        }
    }

    public void exit() {
        currentShop = null;
    }

    public void buy(int numberOfItemsPurchased) {
        if (currentShop != null) {
            int s = currentShop.getPrice() * numberOfItemsPurchased;
            if (isUnlimitedBudget || budget >= s + amountSpent) {
                amountSpent = amountSpent + s;
                currentShop.sell(numberOfItemsPurchased); 
            }
        }
    }

    public int getBudget() {
        return budget;
    }

    public Shop getCurrentShop() {
        return currentShop;
    }

    public boolean hasUnlimitedBudget() {
        return isUnlimitedBudget;
    }

    public void setBudget(int getBudget) {
        this.isUnlimitedBudget = false;
        budget = getBudget;
    }

    public int totalBudget() {
        return budget;
    }
}

