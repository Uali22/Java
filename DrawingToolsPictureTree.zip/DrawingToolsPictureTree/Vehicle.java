
/**
 * This class is for your week 1 portfolio project.
 * You need to draw a picture of a vehicle and add methods to move
 * the vehicle right and left across the canvas.
 * Put your name into the template below:
 * 
 * @author (Usman Ali) 
 * @version (a version number or a date)
 */
public class Vehicle
{
    // instance variables.  Declare the shapes you will use.
    // See the picture class for an example.
    private Rectangle chassis;
    private Circle wheel1;
    private Circle wheel2;
    private Rectangle roof;
    private Rectangle window1;
    private Rectangle window2;
    private int x,y;
    /**
     * Constructor for objects of class Vehicle.
     */
    public Vehicle()
    {
        // nothing to do here
    }

    /**
     * Draw your vehicle.
     */
    public void draw()
    {
        // chassis of car
        chassis = new Rectangle();
        chassis.changeColor("green");
        chassis.moveHorizontal(340);
        chassis.moveVertical(260);
        chassis.changeSize(215,50);
        chassis.makeVisible();

        // front wheel of car
        wheel1 = new Circle();
        wheel1.changeColor("black");
        wheel1.moveHorizontal(375);
        wheel1.moveVertical(315);
        wheel1.changeSize(40);
        wheel1.makeVisible();

        // back wheel of car
        wheel2 = new Circle();
        wheel2.changeColor("black");
        wheel2.moveHorizontal(515);
        wheel2.moveVertical(315);
        wheel2.changeSize(39);
        wheel2.makeVisible();

        // roof of car
        roof = new Rectangle();
        roof.changeColor("green");
        roof.moveHorizontal(385);
        roof.moveVertical(220);
        roof.changeSize(129,55);
        roof.makeVisible();

        // left window
        window1 = new Rectangle();
        window1.changeColor("black");
        window1.moveHorizontal(399);
        window1.moveVertical(230);
        window1.changeSize(45,30);
        window1.makeVisible();

        // right window
        window2 = new Rectangle();
        window2.changeColor("black");
        window2.moveHorizontal(455);
        window2.moveVertical(230);
        window2.changeSize(45,30);
        window2.makeVisible();
    }

    /**
     * Move your vehicle a little to the right.
     */
    public void moveRight()
    {

        chassis.slowMoveHorizontal(200);
        wheel1.slowMoveHorizontal(200);
        wheel2.slowMoveHorizontal(200);
        roof.slowMoveHorizontal(200);
        window1.slowMoveHorizontal(200);
        window2.slowMoveHorizontal(200);
    }

    /**
     * Move your vehicle a little to the left.
     */
    public void moveLeft()
    {
        // put your code here
        chassis.slowMoveHorizontal(-200);
        wheel1.slowMoveHorizontal(-200);
        wheel2.slowMoveHorizontal(-200);
        roof.slowMoveHorizontal(-200);
        window1.slowMoveHorizontal(-200);
        window2.slowMoveHorizontal(-200);
    }
}