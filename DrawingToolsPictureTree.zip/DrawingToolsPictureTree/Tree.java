
/**
 * This class represents a tree which we can draw on the canvas.
 *
 * @author Tony Beaumont
 * @version 1
 */
public class Tree
{
    // instance variables - replace the example below with your own
    int x;  // x coordinate of the tree
    int y;  // y coordinate of the tree
    Rectangle trunk;
    Circle leaves;

    /**
     * Constructor for objects of class Tree
     */
    public Tree()
    {
        // initialise instance variables
        x = 300;
        y = 300;
    }
    
    /**
     * Draw this picture.
     */
    public void draw()
    {
        // this bit draws the trunk
        trunk = new Rectangle();
        trunk.setPosition(x, y);
        trunk.changeSize(15, 75);
        trunk.changeColor("117,66,13");
        trunk.makeVisible();
        // this bit draws the leaves
        leaves = new Circle();
        leaves.changeSize(80);
        leaves.changeColor("green");
        leaves.setPosition(x+7, y-40);
        leaves.makeVisible();
    }
    
    /**
     * Move the tree to a new position.
     */
    public void move(int newX, int newY) {
        x = newX;
        y = newY;
        trunk.setPosition(x,y);
        leaves.setPosition(x+7, y-40);
    }

}
