
/**
 * Write a description of class TicketMachine here.
 *
 * @author (Usman Ali)
 * @version (a version number or a date)
 */
public class TicketMachine
{
    private int price;
    private int balance;
    private int total;

    public TicketMachine(int price){
        this.price = price;
        this.balance = 0;
        this.total = 0;
    }

    public void insertMoney(int amount) {
        balance = balance + amount;
    }

    public void printTicket() {
        total = total + balance;
        balance = 0;
        //System.out.Printin("Here is your ticket: price" = + price);
    }

    public int getPrice(){
        return price;
    }

    public int getBalance(){
        return balance;
    }

    public int getTotal(){
        return total;
    } 
}